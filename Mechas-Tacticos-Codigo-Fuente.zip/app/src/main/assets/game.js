const N=20,BASE=48,VIS=8,SCAN=12,MAP=1024,S=MAP/N;
const cv=document.getElementById('c'),g=cv.getContext('2d');
let W=0,z=1,camx=0,camy=0,showB=true,pixelRatio=1;
const img=new Image();img.onload=()=>draw();img.src='mapa.jpg';
const SPR={P:{i:new Image(),px:82.1,py:120.2,bw:182.1,fr:1,amp:9,rig:{ay:128.0,ax1:32.7,ax2:133.5,ly:155.3,mx:83.3,ov:12}},E:{i:new Image(),px:150.2,py:113.9,bw:298.8,fr:1.3,amp:10,rig:{ay:99.7,ax1:72.7,ax2:227.9,ly:138.5,mx:150.3,ov:12}}};
SPR.P.i.onload=SPR.E.i.onload=()=>draw();
SPR.P.i.src='vanguard.png';SPR.E.i.src='aegis.png';
const RECTS=[[225,0,400,62],[615,0,805,48],[940,35,998,82],[22,105,72,152],[0,190,78,402],[940,220,1022,392],
[203,183,358,235],[203,253,305,333],[208,343,300,392],[330,170,407,207],[395,288,456,396],[240,415,390,445],
[612,175,718,243],[725,180,822,228],[730,218,818,305],[612,290,712,410],[716,318,820,410],[728,418,785,450],
[224,568,332,672],[348,578,420,680],[222,668,278,702],[332,738,408,770],
[582,552,822,662],[582,628,612,768],[618,685,665,768],[662,628,768,692],[720,730,810,770],
[940,585,1022,785],[0,612,82,818],[378,533,428,556],[740,528,785,565],[885,705,912,745],[935,822,998,860],[105,722,130,770],[100,342,125,400],
[258,918,408,1015],[425,918,462,985],[615,925,805,1015],[830,935,900,998]];
const walls=new Set();
RECTS.forEach(([x1,y1,x2,y2])=>{for(let a=0;a<N;a++)for(let b=0;b<N;b++){
const ox=Math.min(x2,(a+1)*S)-Math.max(x1,a*S),oy=Math.min(y2,(b+1)*S)-Math.max(y1,b*S);
if(ox>0&&oy>0&&ox*oy>=.35*S*S)walls.add(a+','+b)}});
const BASES={P:{x:1,y:17,w:3,h:3},E:{x:15,y:1,w:3,h:3}};
for(const b of[BASES.P,BASES.E])for(let a=0;a<b.w;a++)for(let c=0;c<b.h;c++)walls.delete((b.x+a)+','+(b.y+c));
const mk=(n,x,y,col,dir)=>({n,x,y,col,dir,en:6,tot:36,moved:false,p:{Pecho:12,Cabeza:6,Brazos:9,Piernas:9}});
let P,E,log,over,turn,pt,scn=null,mode=null,fx=[],fxRun=false,rxCb=null,cp={m:'n',part:null},modLock=false,dialogType='',matchVersion=0,keyboardCell=null;
const SAVE_KEY='mechas-tacticos.v1';
const DIRECTIONS=[[1,0],[-1,0],[0,1],[0,-1]];
const reduceMotion=matchMedia('(prefers-reduced-motion: reduce)');
const gridKey=(x,y)=>x+','+y;
const inside=(x,y)=>x>=0&&y>=0&&x<N&&y<N;
const canAct=()=>pt&&!over&&!anim;
function later(callback,ms){
  const version=matchVersion;
  setTimeout(()=>{if(version===matchVersion)callback()},reduceMotion.matches?Math.min(ms,65):ms);
}
const shk={t:0,a:0};
const dist=(a,b)=>Math.abs(a.x-b.x)+Math.abs(a.y-b.y);
const $=id=>document.getElementById(id);
const ITEMS={rf:{n:'Rifle RF-12',t:'arma',d:8,r:5,w:4,am:12,rf:true},ca:{n:'Cañón CG-30',t:'arma',d:10,r:4,w:9,am:6,rf:false},sm:{n:'Subfusil SM-7',t:'arma',d:6,r:3,w:3,am:24,rf:true},el:{n:'Escudo ligero',t:'escudo',def:1,w:3},ep:{n:'Escudo pesado',t:'escudo',def:2,w:7}};
function refill(m){for(const id of[m.eq.R,m.eq.L,...m.bag])if(ITEMS[id].am)m.am[id]=ITEMS[id].am}
const inBase=m=>{const b=m==P?BASES.P:BASES.E;return m.x>=b.x&&m.x<b.x+b.w&&m.y>=b.y&&m.y<b.y+b.h};
const wp=m=>ITEMS[m.eq.R],rng=m=>wp(m).r,wt=m=>m.bw+ITEMS[m.eq.R].w+ITEMS[m.eq.L].w,seen=()=>dist(P,E)<=VIS;
const T=()=>BASE*z;
function clamp(){const w=N*T();camx=Math.max(0,Math.min(camx,w-W));camy=Math.max(0,Math.min(camy,w-W))}
function look(x,y){camx=(x+.5)*T()-W/2;camy=(y+.5)*T()-W/2;clamp()}
function start(write=true){
  matchVersion++;
  closeDialog();
  P=mk('Vanguard MK-II',2,18,'#4a8fd4',[1,-1]);
  E=mk('Aegis Bastión',17,2,'#d9a23a',[-1,1]);
  P.eq={R:'rf',L:'el'};P.bag=['sm','ep','ca'];P.bw=20;P.cap=32;
  E.eq={R:'ca',L:'ep'};E.bag=[];E.bw=24;E.cap=40;
  P.am={};E.am={};refill(P);refill(E);
  fx=[];shk.t=0;over=false;turn=1;pt=true;anim=false;scn=null;mode=null;
  selPart=null;keyboardCell=null;z=1;
  log=['Tu turno. Toca una casilla azul para avanzar. Pulsa «Fin de turno» cuando termines.'];
  look(P.x,P.y);ui();draw();if(write)saveBattle();
}
function snapshotUnit(m){
  const {x,y,p,eq,bag,am,en,moved,dir}=m;
  return {x,y,p,eq,bag,am,en,moved,dir};
}
function saveBattle(){
  if(anim||(!pt&&!over))return;
  try{
    localStorage.setItem(SAVE_KEY,JSON.stringify({
      version:1,turn,over,pt,log,scn,P:snapshotUnit(P),E:snapshotUnit(E)
    }));
  }catch(error){ $('save-status').textContent='Guardado no disponible'; }
}
function restoreUnit(unit,data){
  const number=(v,max,min=0)=>Number.isInteger(v)&&v>=min&&v<=max;
  const keys=Object.keys(MX);
  if(!data||!number(data.x,N-1)||!number(data.y,N-1)||walls.has(gridKey(data.x,data.y))||
    !number(data.en,6)||typeof data.moved!=='boolean'||!data.p||
    !keys.every(k=>number(data.p[k],MX[k]))||
    !data.eq||!ITEMS[data.eq.R]||ITEMS[data.eq.R].t!=='arma'||
    !ITEMS[data.eq.L]||ITEMS[data.eq.L].t!=='escudo'||!Array.isArray(data.bag)||
    [...data.bag,data.eq.R,data.eq.L].sort().join()!==[...unit.bag,unit.eq.R,unit.eq.L].sort().join()||
    !data.am||[...data.bag,data.eq.R].some(k=>ITEMS[k].am&&!number(data.am[k],ITEMS[k].am))||
    !Array.isArray(data.dir)||data.dir.length!==2||!data.dir.every(v=>number(v,N-1,-(N-1))))return false;
  for(const key of ['x','y','en','moved','eq','am','bag','dir'])unit[key]=data[key];
  unit.p={};for(const key of keys)unit.p[key]=data.p[key];
  unit.tot=Object.values(unit.p).reduce((a,b)=>a+b,0);
  return wt(unit)<=unit.cap;
}
function restoreBattle(){
  try{
    const raw=localStorage.getItem(SAVE_KEY);
    if(!raw)return false;
    const data=JSON.parse(raw);
    if(!data||data.version!==1||!Number.isSafeInteger(data.turn)||data.turn<1||
      typeof data.over!=='boolean'||typeof data.pt!=='boolean'||(!data.pt&&!data.over)||
      !Array.isArray(data.log)||!data.log.every(line=>typeof line==='string'))return false;
    const player={...P},enemy={...E};
    if(!restoreUnit(player,data.P)||!restoreUnit(enemy,data.E)||dist(player,enemy)===0||
      data.over!==(player.p.Pecho===0||enemy.p.Pecho===0))return false;
    P=player;E=enemy;over=data.over;pt=data.pt;turn=data.turn;
    log=data.log.slice(-7).map(line=>line.slice(0,350));
    const mark=data.scn&&data.scn.z;
    scn=data.scn?{z:mark&&Number.isInteger(mark.x)&&Number.isInteger(mark.y)&&inside(mark.x,mark.y)?{x:mark.x,y:mark.y}:null}:null;
    look(P.x,P.y);ui();draw();
    return true;
  }catch(error){return false}
}
function size(){
  const old=W?[(camx+W/2)/T(),(camy+W/2)/T()]:null;
  const width=$('board').getBoundingClientRect().width;
  const heightLimit=innerWidth<=740&&innerHeight>=innerWidth
    ? Math.max(230,innerHeight-245) : window.innerHeight*.68;
  W=Math.max(1,Math.floor(Math.min(width,heightLimit,680)));
  pixelRatio=Math.max(1,Math.min(window.devicePixelRatio||1,3));
  cv.style.width=W+'px';cv.style.height=W+'px';
  cv.width=Math.round(W*pixelRatio);cv.height=Math.round(W*pixelRatio);
  z=Math.max(z,W/(N*BASE));
  if(old){camx=old[0]*T()-W/2;camy=old[1]*T()-W/2}
  clamp();draw();
}
function zoom(f,x=W/2,y=W/2){
  const wx=(camx+x)/T(),wy=(camy+y)/T();
  z=Math.max(W/(N*BASE),Math.min(2,z*f));
  camx=wx*T()-x;camy=wy*T()-y;clamp();draw();
}
function reach(m,o){const cost=m.p.Piernas>0?1:2,d={},q=[[m.x,m.y,0]];d[m.x+','+m.y]=0;
while(q.length){const[x,y,c]=q.shift();for(const[dx,dy]of DIRECTIONS){
const nx=x+dx,ny=y+dy,k=nx+','+ny,nc=c+cost;
if(nx<0||ny<0||nx>=N||ny>=N||walls.has(k)||(nx==o.x&&ny==o.y)||nc>m.en||(k in d&&d[k]<=nc))continue;d[k]=nc;q.push([nx,ny,nc])}}
delete d[m.x+','+m.y];return d}
const PM={Pecho:0,Brazos:1,Piernas:1,Cabeza:2},MT={n:0,a:-1,r:1};
const d6=()=>1+Math.floor(Math.random()*6);
const attackCost=m=>m==='a'?2:1;
const ammoCost=m=>m==='r'?3:1;
const canFire=(a,t,m='n')=>!over&&a.p.Brazos>0&&dist(a,t)<=rng(a)&&
  a.en>=attackCost(m)&&a.am[a.eq.R]>=ammoCost(m)&&(m!=='r'||wp(a).rf);
const attackProblem=()=>P.p.Brazos===0?'Los brazos están destruidos. Vuelve a tu base para repararlos.':
  dist(P,E)>rng(P)?'Fuera de alcance. Máximo '+rng(P)+' casillas.':
  P.en<1?'No te queda energía para disparar.':'Sin munición. Cambia de arma o vuelve a tu base.';
function pickPart(t){const ks=Object.keys(t.p).filter(k=>t.p[k]>0),wg={Pecho:3,Cabeza:1,Brazos:2,Piernas:2};let tot=ks.reduce((q,k)=>q+wg[k],0),x=Math.random()*tot;for(const k of ks){x-=wg[k];if(x<=0)return k}return ks[0]}
function odds(a,plan){
  const modifier=(a.moved?0:-1)+MT[plan.m]+(plan.part?PM[plan.part]:0);
  let misses=0,precise=0;
  for(let die=1;die<=6;die++){
    const result=Math.min(6,Math.max(1,die+modifier));
    if(result===6)misses++;
    if(result===1&&a.p.Cabeza>0)precise++;
  }
  const missPercent=Math.round(misses*100/6),precisePercent=Math.round(precise*100/6);
  return [missPercent,100-missPercent-precisePercent,precisePercent];
}
function eRx(){if(E.en>=1&&E.p.Piernas>0&&Math.random()<.2)return{k:'d'};if(E.p.Brazos>0&&ITEMS[E.eq.L].t=='escudo'&&Math.random()<.35)return{k:'b'};return null}
function ePlan(){const w=wp(E),r=Math.random();let m='n';if(w.rf&&E.am[E.eq.R]>=3&&r<.25)m='r';else if(E.en>=2&&r<.5)m='a';
const ks=Object.keys(P.p).filter(k=>P.p[k]>0);return{m,part:Math.random()<.4?ks[Math.floor(Math.random()*ks.length)]:null}}
function addFx(o){o.t0=performance.now();fx.push(o);if(!fxRun){fxRun=true;requestAnimationFrame(fxTick)}}
function fxTick(){draw();if(fx.length||performance.now()<shk.t)requestAnimationFrame(fxTick);else{fxRun=false;draw()}}
function drawFx(){const n=performance.now(),t=T(),X=x=>(x+.5)*t-camx,Y=y=>(y+.5)*t-camy;
for(const e of fx){const p=(n-e.t0)/e.d;if(p<0||p>1||reduceMotion.matches&&e.k!=='tx')continue;
if(e.k=='tr'){const q=Math.max(0,p-.2),hx=e.x1+(e.x2-e.x1)*p,hy=e.y1+(e.y2-e.y1)*p,tx=e.x1+(e.x2-e.x1)*q,ty=e.y1+(e.y2-e.y1)*q;g.strokeStyle=e.c;g.lineWidth=e.w;g.lineCap='round';g.beginPath();g.moveTo(X(tx),Y(ty));g.lineTo(X(hx),Y(hy));g.stroke();g.lineCap='butt';g.lineWidth=1}
else if(e.k=='fl'){g.fillStyle='rgba(255,235,160,'+(1-p)+')';g.beginPath();g.arc(X(e.x),Y(e.y),t*(.12+.22*p)*e.s,0,7);g.fill()}
else if(e.k=='bm'){const R=t*(.15+.55*p)*e.s;g.fillStyle='rgba('+e.c+','+(.55*(1-p))+')';g.beginPath();g.arc(X(e.x),Y(e.y),R,0,7);g.fill();
g.strokeStyle='rgba(255,255,255,'+(1-p)+')';g.lineWidth=2;g.beginPath();g.arc(X(e.x),Y(e.y),R*1.1,0,7);g.stroke();g.lineWidth=1;
g.fillStyle='rgba('+e.c+','+(1-p)+')';for(let i=0;i<9;i++){const a=i*.7+e.r,rr=R*(1.1+p*.8);g.fillRect(X(e.x)+Math.cos(a)*rr-2,Y(e.y)+Math.sin(a)*rr-2,4,4)}}
else if(e.k=='sh'){const a=Math.atan2(e.dy,e.dx);g.strokeStyle='rgba(120,200,255,'+(1-p)+')';g.lineWidth=5;g.beginPath();g.arc(X(e.x),Y(e.y),t*(.45+.1*p),a-1,a+1);g.stroke();g.lineWidth=1}
else if(e.k=='tx'){g.globalAlpha=1-p*p;g.fillStyle=e.c;g.strokeStyle='#111';g.lineWidth=3;g.font='bold '+Math.floor(t*.5)+'px sans-serif';g.textAlign='center';g.textBaseline='middle';
const yy=Y(e.y)-t*.55-p*t*.8;g.strokeText(e.s,X(e.x),yy);g.fillText(e.s,X(e.x),yy);g.globalAlpha=1;g.lineWidth=1}}
fx=fx.filter(e=>n-e.t0<=e.d)}
function fire(a,t,p,rx,done){
const w=wp(a),n=p.m=='r'?2:1;let i=0,dodged=false,block=false;
if(!canFire(a,t,p.m)){if(done)done();return}
anim=true;a.en-=attackCost(p.m);a.am[a.eq.R]-=ammoCost(p.m);ui();
if(t==E)rx=eRx();
if(rx&&rx.k=='d'){t.en--;dodged=d6()+(t.p.Piernas>0?1:-2)>=5}
if(rx&&rx.k=='b')block=true;
const sdi=ITEMS[t.eq.L],sdOK=sdi.t=='escudo'&&t.p.Brazos>0,TR=w.d>=10?330:230,now=()=>performance.now();
if(rx&&rx.k=='d')say(t.n+(dodged?' esquiva el ataque.':' intenta esquivar y falla.'));
if(rx&&rx.k=='b'&&sdOK)say(t.n+' se cubre con el escudo.');
const finish=()=>{anim=false;ui();draw();saveBattle();
if(rx&&rx.k=='c'&&a==E&&canFire(P,E)){say('Contraatacas.');return fire(P,E,{m:'n',part:null},null,done)}
done&&done()};
const hit=()=>{const raw=d6(),m=(a.moved?0:-1)+MT[p.m]+(p.part?PM[p.part]:0),r=Math.min(6,Math.max(1,raw+m));
let txt='dado '+raw+(m?' ('+(m>0?'+':'−')+Math.abs(m)+')':'')+' → ',ft=null,fc='#ccc';
if(dodged){txt+='esquivado';ft='Esquivado';t.dg=now()+350}
else if(r==6){txt+='fallo';ft='Fallo';addFx({k:'bm',x:t.x+Math.sign(t.x-a.x)*.8,y:t.y+Math.sign(t.y-a.y)*.8,d:260,s:.5,c:'180,180,180',r:0})}
else{const full=r==1&&a.p.Cabeza>0;let dmg=full?w.d:Math.round(w.d/2);txt+=full?'impacto preciso':'impacto parcial';
const sh=sdOK?(block?sdi.def+1:sdi.def):0;if(sh){dmg=Math.max(0,dmg-sh);txt+=' (escudo −'+sh+')'}
if(dmg<=0){txt+=', daño absorbido';ft='Bloqueado';fc='#7cc4ff';addFx({k:'sh',x:t.x,y:t.y,d:380,dx:a.x-t.x,dy:a.y-t.y})}
else{const k=p.part&&t.p[p.part]>0?p.part:pickPart(t);dmg=Math.min(dmg,t.p[k]);t.p[k]-=dmg;t.tot-=dmg;const dead=t.p[k]==0;
txt+=' en '+k+' (−'+dmg+')'+(dead?' · pieza destruida':'');ft='−'+dmg;fc=full?'#ff5a3c':'#ffb13c';
addFx({k:'bm',x:t.x,y:t.y,d:dead?650:420,s:dead?1.6:1,c:dead?'255,120,40':'255,200,90',r:Math.random()*6});
t.shk=now()+320;t.fl=now()+260;shk.t=now()+(dead?450:280);shk.a=dead?9:5;
if(t.p.Pecho==0||t.tot==0){over=true;txt+='. '+(t==E?'¡Victoria!':'Derrota: cabina destruida.')}}}
if(ft)addFx({k:'tx',x:t.x,y:t.y,d:900,s:ft,c:fc});
say(a.n+': '+txt)};
const one=()=>{if(i>=n||over)return finish();i++;
a.dir=[t.x-a.x,t.y-a.y];look((a.x+t.x)/2,(a.y+t.y)/2);
addFx({k:'fl',x:a.x+Math.sign(t.x-a.x)*.4,y:a.y+Math.sign(t.y-a.y)*.4,d:140,s:1});
addFx({k:'tr',x1:a.x,y1:a.y,x2:t.x,y2:t.y,d:TR,c:w.d>=10?'#ff9a3c':'#ffe9a0',w:w.d>=10?5:3});
later(()=>{hit();later(one,i<n?240:480)},TR)};
one()}
function react(p,cb){const w=wp(E),nm={n:'Disparo',a:'Disparo apuntado',r:'Ráfaga'}[p.m];
const canB=P.p.Brazos>0&&ITEMS[P.eq.L].t=='escudo',canD=P.en>=1&&P.p.Piernas>0,canC=canFire(P,E);
look((E.x+P.x)/2,(E.y+P.y)/2);draw();rxCb=cb;
show('<div class="sit"><b>'+E.n+' te ataca</b></div><div class="v2">'+nm+' con '+w.n+(p.part?', apunta a tu '+p.part:', sin apuntar')+'. ¿Cómo reaccionas?</div><div class="grid g2">'+
'<button class="opt" data-rx="b"'+(canB?'':' disabled')+'><b>Bloquear</b><small>0 energía · el escudo absorbe +1 extra</small></button>'+
'<button class="opt" data-rx="d"'+(canD?'':' disabled')+'><b>Esquivar</b><small>1 energía · 50 % de evitarlo</small></button>'+
'<button class="opt" data-rx="c"'+(canC?'':' disabled')+'><b>Contraatacar</b><small>1 energía · respondes tras el impacto</small></button>'+
'<button class="opt" data-rx="n"><b>Recibir</b><small>sin reacción</small></button></div>',true,'reacción')}
function openAtk(){cp={m:'n',part:null};renderAtk()}
function renderAtk(){const w=wp(P),a=P.am[P.eq.R];
const T3=[['n','Disparo','1 energía · 1 munición',canFire(P,E)],['a','Apuntado','2 energía · 1 munición · +precisión',canFire(P,E,'a')],['r','Ráfaga','1 energía · 3 munición · 2 disparos',canFire(P,E,'r')]];
if(!T3.find(q=>q[0]==cp.m)[3])cp.m=(T3.find(q=>q[3])||T3[0])[0];
const ok=T3.find(q=>q[0]==cp.m)[3],[f,pa,x]=odds(P,cp),sd=ITEMS[E.eq.L],sh=sd.t=='escudo'&&E.p.Brazos>0?sd.def:0;
const parts=[''].concat(Object.keys(MX));
show('<div class="sit"><b>Atacar a '+E.n+'</b><span class="v2">Distancia '+dist(P,E)+' · alcance '+w.r+'</span></div><div class="v2">'+w.n+' · Munición '+a+'/'+w.am+' · Energía '+P.en+'/6</div>'+
'<div class="sit" style="margin-top:8px"><b>Tipo de ataque</b></div><div class="grid">'+T3.map(q=>'<button class="opt'+(cp.m==q[0]?' on':'')+'" data-ap="'+q[0]+'"'+(q[3]?'':' disabled')+'><b>'+q[1]+'</b><small>'+q[2]+'</small></button>').join('')+'</div>'+
'<div class="sit" style="margin-top:8px"><b>Parte objetivo</b></div><div class="grid g5">'+parts.map(k=>{const st=k?sc(E.p[k],MX[k]):['',''],dead=k&&E.p[k]<=0;
return '<button class="opt'+(cp.part==(k||null)?' on':'')+'" data-pp="'+k+'"'+(dead?' disabled':'')+'>'+(k?'<i class="dot '+st[0]+'"></i>':'')+'<b>'+(k||'Libre')+'</b><small>'+(k?(PM[k]?'dado +'+PM[k]:'normal'):'sin penaliz.')+'</small></button>'}).join('')+'</div>'+
'<div class="st2" style="margin-top:8px"><span>Probabilidad</span><span>Fallo '+f+' % · Parcial '+pa+' % · Preciso '+x+' %</span></div><div class="st2"><span>Daño por impacto</span><span>'+w.d+' / '+Math.round(w.d/2)+(sh?' (escudo enemigo −'+sh+')':'')+'</span></div>'+
'<button class="eqb" id="fireb"'+(ok?'':' disabled')+' style="margin-top:10px">'+(ok?'Disparar':'Sin recursos para este ataque')+'</button>',false,'ataque')}
function go(){
  if(!canAct()||!canFire(P,E,cp.m)||!seen())return;
  const plan={m:cp.m,part:cp.part};
  closeDialog();fire(P,E,plan,null);
}
function say(s){
  log.push(s);if(log.length>7)log.shift();
  ui();draw();saveBattle();
}
function tap(px,py){
  if(!canAct()||!$('mod').hidden)return;
  const x=Math.floor((px+camx)/T()),y=Math.floor((py+camy)/T()),k=gridKey(x,y);
  if(!inside(x,y))return;
  if(x===E.x&&y===E.y&&seen()){
    if(mode==='an')return openAn();
    if(!canFire(P,E))return say(attackProblem());
    return openAtk();
  }
  const d=reach(P,E);
  if(k in d){
    const path=route(P,d,x,y);
    P.en-=d[k];P.moved=true;mode=null;
    walk(P,path);
  }
}
let anim=false;
function route(m,d,x,y){const cost=m.p.Piernas>0?1:2,p=[[x,y]];let c=d[x+','+y];
while(c>0){const[cx,cy]=p[0];let nx=null;for(const[dx,dy]of DIRECTIONS){const px=cx+dx,py=cy+dy,pc=(px==m.x&&py==m.y)?0:d[px+','+py];
if(pc===c-cost){nx=[px,py];break}}if(!nx)break;p.unshift(nx);c-=cost}return p}
function walk(m,path,done){
  anim=true;ui();
  const version=matchVersion;
  const duration=reduceMotion.matches?0:180;
  let i=1;
  function segment(){
    if(i>=path.length){
      anim=false;m.fx=m.fy=null;m.ph=0;
      if(m===P)keyboardCell=null;
      ui();draw();saveBattle();
      if(done)done();
      return;
    }
    const a=path[i-1],b=path[i],startTime=performance.now(),phase=m.ph||0;
    m.dir=[b[0]-a[0],b[1]-a[1]];
    function frame(now){
      if(version!==matchVersion)return;
      const u=duration?Math.min(1,(now-startTime)/duration):1;
      m.fx=a[0]+(b[0]-a[0])*u;m.fy=a[1]+(b[1]-a[1])*u;m.ph=phase+u;
      if(m===P||seen())look(m.fx,m.fy);
      draw();
      if(u<1){requestAnimationFrame(frame);return}
      m.x=b[0];m.y=b[1];m.fx=m.fy=null;i++;segment();
    }
    requestAnimationFrame(frame);
  }
  segment();
}
const pointers=new Map();
let dragged=false,lastGesture=null;
function gesture(){
  const points=Array.from(pointers.values()),a=points[0],b=points[1];
  return b?{x:(a.x+b.x)/2,y:(a.y+b.y)/2,span:Math.hypot(a.x-b.x,a.y-b.y)}:
    {x:a.x,y:a.y,span:0};
}
cv.addEventListener('pointerdown',e=>{
  if(e.pointerType==='mouse'&&e.button!==0||pointers.size>=2)return;
  if(!pointers.size){dragged=false;keyboardCell=null}
  pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(pointers.size===2)dragged=true;
  lastGesture=gesture();cv.setPointerCapture(e.pointerId);
});
cv.addEventListener('pointermove',e=>{
  if(!pointers.has(e.pointerId))return;
  pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  const next=gesture(),rect=cv.getBoundingClientRect();
  if(!dragged&&Math.hypot(next.x-lastGesture.x,next.y-lastGesture.y)<8)return;
  dragged=true;
  camx-=next.x-lastGesture.x;camy-=next.y-lastGesture.y;
  if(next.span>0&&lastGesture.span>0)zoom(next.span/lastGesture.span,next.x-rect.left,next.y-rect.top);
  else{clamp();draw()}
  lastGesture=next;
});
function endPointer(e){
  if(!pointers.has(e.pointerId))return;
  pointers.delete(e.pointerId);
  if(e.type==='pointerup'&&!dragged&&!pointers.size){
    const r=cv.getBoundingClientRect();
    tap(e.clientX-r.left,e.clientY-r.top);
  }
  lastGesture=pointers.size?gesture():null;
}
for(const type of ['pointerup','pointercancel','lostpointercapture'])cv.addEventListener(type,endPointer);
cv.addEventListener('keydown',e=>{
  const keys=['ArrowRight','ArrowLeft','ArrowDown','ArrowUp'];
  if(keys.includes(e.key)){
    e.preventDefault();
    const [dx,dy]=DIRECTIONS[keys.indexOf(e.key)];
    const [x,y]=keyboardCell||[P.x,P.y];
    if(inside(x+dx,y+dy)){keyboardCell=[x+dx,y+dy];look(...keyboardCell);draw()}
  }else if(e.key==='Enter'||e.key===' '){
    e.preventDefault();
    if(keyboardCell)tap((keyboardCell[0]+.5)*T()-camx,(keyboardCell[1]+.5)*T()-camy);
  }
});
$('zi').onclick=()=>zoom(1.25);
$('zo').onclick=()=>zoom(.8);
$('ce').onclick=()=>{look(P.x,P.y);draw()};
$('bl').onclick=()=>{
  showB=!showB;$('bl').setAttribute('aria-pressed',String(showB));draw();
};
$('end').onclick=()=>{
  if(!canAct())return;
  pt=false;mode=null;E.en=6;E.moved=false;
  say('Turno enemigo…');if(seen())look(E.x,E.y);draw();later(estep,500);
};
$('rst').onclick=()=>show('<h2>Nueva batalla</h2><p>Se reemplazará la batalla guardada.</p>'+
  '<button class="eqb" id="restart-confirm">Iniciar nueva batalla</button>',false,'reinicio');
function toGoal(m,opponent,goals){
  const remaining=new Map(),queue=[];
  for(const [x,y] of goals){
    const key=gridKey(x,y);
    if(walls.has(key)||(x===opponent.x&&y===opponent.y))continue;
    remaining.set(key,0);queue.push([x,y]);
  }
  for(let i=0;i<queue.length;i++){
    const [x,y]=queue[i],cost=remaining.get(gridKey(x,y))+1;
    for(const [dx,dy] of DIRECTIONS){
      const nx=x+dx,ny=y+dy,key=gridKey(nx,ny);
      if(!inside(nx,ny)||walls.has(key)||(nx===opponent.x&&ny===opponent.y)||remaining.has(key))continue;
      remaining.set(key,cost);queue.push([nx,ny]);
    }
  }
  const reachable=reach(m,opponent);
  let best=null,distance=remaining.get(gridKey(m.x,m.y));
  for(const [key,cost] of Object.entries(reachable)){
    const steps=remaining.get(key);
    if(steps===undefined||!(steps<distance||best&&steps===distance&&cost<best.cost))continue;
    const [x,y]=key.split(',').map(Number);
    // Preserve one point for a shot when there is a reachable firing position.
    if(steps===0&&!retreating(m)&&cost>=m.en)continue;
    distance=steps;best={x,y,cost};
  }
  return best&&{cost:best.cost,path:route(m,reachable,best.x,best.y)};
}
const retreating=m=>m.p.Brazos===0||m.am[m.eq.R]<=0;
function rearm(m){
  m.en-=2;refill(m);
  if(m.p.Brazos===0){m.p.Brazos=3;m.tot+=3;return true}
  return false;
}
function estep(){
  if(over)return;
  if(canFire(E,P)){
    const plan=ePlan();
    react(plan,k=>fire(E,P,plan,{k},()=>later(estep,420)));
    return;
  }
  const retreat=retreating(E);
  if(retreat&&inBase(E)&&E.en>=2){
    const repaired=rearm(E);
    if(seen())say(repaired?'El enemigo repara sus brazos y recarga.':'El enemigo se reabastece.');
    return later(estep,420);
  }
  if(!retreat||!inBase(E)){
    const goals=[],base=BASES.E;
    for(let x=0;x<N;x++)for(let y=0;y<N;y++){
      if(retreat?(x>=base.x&&x<base.x+base.w&&y>=base.y&&y<base.y+base.h):
        dist({x,y},P)<=rng(E))goals.push([x,y]);
    }
    const step=toGoal(E,P,goals);
    if(step){E.en-=step.cost;E.moved=true;return walk(E,step.path,()=>later(estep,350))}
  }
  turn++;scn=null;mode=null;P.en=6;P.moved=false;pt=true;look(P.x,P.y);
  say('Turno '+turn+'. Tu turno.');
}
function card(m){
  const weapon=wp(m);
  return '<b>'+m.n+'</b><div class="p">Energía '+m.en+'/6 · Integridad '+m.tot+'/36</div>'+
    '<div class="p">Munición '+m.am[m.eq.R]+'/'+weapon.am+'</div>';
}
const MX={Pecho:12,Cabeza:6,Brazos:9,Piernas:9};
function sc(v,mx){const r=v/mx;return v<=0?['o','Destruida']:r>.7?['g','Buen estado']:r>.35?['y','Dañada']:['r','Estado crítico']}
let selPart=null;
function info(k){if(!k)return '<div class="hint">Toca una pieza del esquema para ver su estado y sus estadísticas.</div>';
const v=P.p[k],mx=MX[k],[c,t]=sc(v,mx),pc=Math.round(v/mx*100);
const D={Pecho:{n:'Pecho y cabina',s:[['Resistencia total',P.tot+'/36']],a:'Alberga la cabina del piloto.',d:'Si se destruye: derrota inmediata.'},
Cabeza:{n:'Cabeza y sensores',s:[['Impacto preciso',v>0?'dado 1 = '+wp(P).d+' de daño':'dado 1 = solo '+Math.round(wp(P).d/2)+' de daño'],['Disparo estático','−1 al dado si no te moviste']],a:'Controla la puntería.',d:'Si se destruye: pierdes los tiros precisos.'},
Brazos:{n:'Brazos, rifle y escudo',s:[[wp(P).n,v>0?wp(P).d+' / '+Math.round(wp(P).d/2)+' de daño, alcance '+wp(P).r:'inutilizable'],[ITEMS[P.eq.L].n,v>0?'defensa '+ITEMS[P.eq.L].def:'inutilizable'],['Munición',P.am[P.eq.R]+'/'+wp(P).am]],a:'Sostienen el arma y el escudo.',d:'Si se destruyen: sin arma ni escudo.'},
Piernas:{n:'Piernas y propulsión',s:[['Caminar',(v>0?1:2)+' de energía por casilla'],['Energía',P.en+'/6']],a:'Dan movilidad al mecha.',d:'Si se destruyen: caminar cuesta el doble.'}}[k];
return '<div class="sit"><b>'+D.n+'</b><span class="tag '+c+'">'+t+'</span></div><div class="bar2 '+c+'"><i style="width:'+pc+'%"></i></div><div class="v2">Integridad '+v+'/'+mx+' ('+pc+' %)</div>'+D.s.map(x=>'<div class="st2"><span>'+x[0]+'</span><span>'+x[1]+'</span></div>').join('')+'<div class="v2">'+D.a+' '+D.d+'</div>'}
function scan(){document.querySelectorAll('#scsvg [data-p]').forEach(el=>{const k=el.dataset.p;el.setAttribute('class','pt '+sc(P.p[k],MX[k])[0]+(k==selPart?' sel':''))});
document.getElementById('scl').innerHTML=Object.keys(MX).map(k=>{const[c,t]=sc(P.p[k],MX[k]);return '<button class="row'+(k==selPart?' sel':'')+'" data-p="'+k+'" aria-pressed="'+(k===selPart)+'"><i class="dot '+c+'"></i><span>'+k+'</span><span class="v">'+P.p[k]+'/'+MX[k]+'</span><em>'+t+'</em></button>'}).join('');
document.getElementById('sci').innerHTML=info(selPart)}
document.getElementById('scan').addEventListener('click',e=>{const el=e.target.closest('[data-p]');if(!el)return;const k=el.dataset.p;selPart=selPart===k?null:k;scan();if(el.tagName==='BUTTON')$('scl').querySelector('[data-p="'+k+'"]').focus()});
function ecard(){return seen()?'<b>'+E.n+'</b><br>Resistencia '+E.tot+'/36<div class="bar2 '+(E.tot>24?'g':E.tot>12?'y':'r')+'"><i style="width:'+Math.round(E.tot/36*100)+'%"></i></div><div class="v2">Toca para analizar</div>':'<b>Enemigo desconocido</b><div class="v2">Sin contacto visual. Usa el escaneo para ubicarlo.</div>'}
function ui(){
  $('hp').innerHTML=card(P);$('he').innerHTML=ecard();
  const lines=log.slice().reverse().map(line=>{
    const item=document.createElement('li');item.textContent=line;return item;
  });
  $('log').textContent='';for(const line of lines)$('log').appendChild(line);
  $('battle-status').textContent=over?(E.p.Pecho===0?'Victoria':'Derrota'):
    anim?'Acción en curso':pt?'Tu turno':'Turno enemigo';
  $('round').textContent='Turno '+turn;
  $('end').disabled=!canAct();
  $('bsc').disabled=!canAct()||P.en<1;
  $('bre').disabled=!canAct()||!inBase(P)||P.en<2;
  $('ban').disabled=!canAct()||!seen();
  $('he').disabled=!canAct()||!seen();
  $('beq').disabled=anim||!pt;
  $('ban').classList.toggle('on',mode==='an');
  $('ban').setAttribute('aria-pressed',String(mode==='an'));
  $('bsc').classList.toggle('on',!!scn);
  scan();
}
function drawMech(q,s,ph){const I=q.i,R=q.rig,W=I.naturalWidth,H=I.naturalHeight,A=Math.sin(ph*Math.PI),a=q.amp,bob=Math.abs(A)*2;
g.rotate(A*.035);
const D=(sx,sy,sw,sh,dy)=>g.drawImage(I,sx,sy,sw,sh,(sx-q.px)*s,(sy-q.py+dy+bob)*s,sw*s,sh*s);
D(0,R.ay-R.ov,R.ax1,H-R.ay+R.ov,-A*a*.8);D(R.ax2,R.ay-R.ov,W-R.ax2,H-R.ay+R.ov,A*a*.8);
D(R.ax1,R.ly-R.ov,R.mx-R.ax1,H-R.ly+R.ov,A*a);D(R.mx,R.ly-R.ov,R.ax2-R.mx,H-R.ly+R.ov,-A*a);
D(0,0,W,R.ay,0);D(R.ax1,R.ay,R.ax2-R.ax1,R.ly-R.ay,0)}
function draw(){if(!W||!P||!E)return;const n=performance.now();g.setTransform(pixelRatio,0,0,pixelRatio,0,0);g.save();if(!reduceMotion.matches&&n<shk.t)g.translate((Math.random()-.5)*shk.a,(Math.random()-.5)*shk.a);draw0();drawFx();g.restore()}
function draw0(){const t=T();g.fillStyle='#2b2e32';g.fillRect(0,0,W,W);
if(img.complete&&img.naturalWidth)g.drawImage(img,-camx,-camy,N*t,N*t);
const d=pt&&!over&&!anim?reach(P,E):{};
for(let x=0;x<N;x++)for(let y=0;y<N;y++){const sx=x*t-camx,sy=y*t-camy;
if(sx>W||sy>W||sx<-t||sy<-t)continue;const kk=x+','+y;
if(showB&&walls.has(kk)){g.fillStyle='rgba(212,83,59,.45)';g.fillRect(sx,sy,t,t)}
else if(kk in d){g.fillStyle='rgba(74,143,212,.4)';g.fillRect(sx,sy,t,t)}
g.strokeStyle='rgba(255,255,255,.18)';g.strokeRect(sx,sy,t,t)}
{const b=BASES.P,bx=b.x*t-camx,by=b.y*t-camy;g.fillStyle='rgba(79,209,139,.16)';g.strokeStyle='rgba(79,209,139,.9)';g.lineWidth=2;g.setLineDash([6,5]);g.fillRect(bx,by,b.w*t,b.h*t);g.strokeRect(bx,by,b.w*t,b.h*t);g.setLineDash([]);
g.fillStyle='#4fd18b';g.font='bold '+Math.floor(t*.4)+'px sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('Base',bx+b.w*t/2,by+b.h*t/2);g.lineWidth=1}
if(scn){g.fillStyle='rgba(232,150,40,.38)';g.strokeStyle='rgba(255,190,80,.9)';g.lineWidth=2;
for(const k of walls){const[x,y]=k.split(',').map(Number),sx=x*t-camx,sy=y*t-camy;if(sx>W||sy>W||sx<-t||sy<-t)continue;g.fillRect(sx,sy,t,t);g.strokeRect(sx+1,sy+1,t-2,t-2)}
if(scn.z){const zx=(scn.z.x+.5)*t-camx,zy=(scn.z.y+.5)*t-camy;g.fillStyle='rgba(212,83,59,.22)';g.strokeStyle='#d4533b';g.setLineDash([8,6]);g.beginPath();g.arc(zx,zy,3.5*t,0,7);g.fill();g.stroke();g.setLineDash([]);
g.fillStyle='#fff';g.font='bold '+Math.floor(t*.8)+'px sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('?',zx,zy)}
g.lineWidth=1}
if(canAct()&&seen()&&canFire(P,E)){g.strokeStyle='#d4533b';g.lineWidth=3;g.strokeRect(E.x*t-camx+2,E.y*t-camy+2,t-4,t-4);g.lineWidth=1}
for(const m of[P,E]){if(m==E&&!seen())continue;const nw=performance.now(),jx=!reduceMotion.matches&&m.shk>nw?(Math.random()-.5)*t*.14:0,jy=!reduceMotion.matches&&m.shk>nw?(Math.random()-.5)*t*.14:0,dgx=!reduceMotion.matches&&m.dg>nw?Math.sin((m.dg-nw)/350*Math.PI)*t*.28:0,cx=(m.fx==null?m.x:m.fx)*t+t/2-camx+jx+dgx,cy=(m.fy==null?m.y:m.fy)*t+t/2-camy+jy,q=SPR[m==P?'P':'E'];
if(q.i.complete&&q.i.naturalWidth){const s=t*q.fr/q.bw,r=Math.atan2(m.dir[1],m.dir[0])-Math.PI/2;
g.save();g.translate(cx,cy);g.rotate(r);drawMech(q,s,m.ph||0);g.restore()}
else{g.fillStyle=m.col;g.beginPath();g.arc(cx,cy,t*.36,0,7);g.fill()}
if(!reduceMotion.matches&&m.fl>nw){g.fillStyle='rgba(255,60,40,'+(.45*(m.fl-nw)/260)+')';g.beginPath();g.arc(cx,cy,t*.45,0,7);g.fill()}
const l=Math.hypot(m.dir[0],m.dir[1])||1,ux=m.dir[0]/l,uy=m.dir[1]/l,ax=cx+ux*t*.62,ay=cy+uy*t*.62;
g.fillStyle='#fff';g.strokeStyle='#111';g.lineWidth=2;g.beginPath();g.moveTo(ax+ux*t*.14,ay+uy*t*.14);
g.lineTo(ax-ux*t*.06-uy*t*.12,ay-uy*t*.06+ux*t*.12);g.lineTo(ax-ux*t*.06+uy*t*.12,ay-uy*t*.06-ux*t*.12);g.closePath();g.fill();g.stroke();g.lineWidth=1}
if(keyboardCell){
  g.strokeStyle='#e5f6ff';g.lineWidth=2;
  g.strokeRect(keyboardCell[0]*t-camx+2,keyboardCell[1]*t-camy+2,t-4,t-4);
  g.lineWidth=1;
}}
let returnFocus=null;
function show(html,locked=false,type='info'){
  const dialog=$('mod'),wasHidden=dialog.hidden;
  modLock=locked;dialogType=type;
  $('mx').hidden=locked;$('mbody').innerHTML=html;
  if(wasHidden){
    returnFocus=document.activeElement;
    dialog.hidden=false;dialog.showModal();
  }
  const first=locked?dialog.querySelector('button:not([disabled]):not([hidden])'):$('mbox');
  if(wasHidden&&first)first.focus();
}
function closeDialog(){
  const dialog=$('mod');
  if(dialog.open)dialog.close();
  dialog.hidden=true;modLock=false;dialogType='';rxCb=null;
  if(returnFocus){returnFocus.focus({preventScroll:true});returnFocus=null}
}
function gameBack(){
  if(!$('mod').hidden){if(!modLock)closeDialog();return true}
  if(mode){mode=null;ui();draw();return true}
  return false;
}
window.gameBack=gameBack;
$('mod').addEventListener('cancel',e=>{e.preventDefault();gameBack()});
function itemRow(l,it,am){return '<div class="st2"><span>'+l+': '+it.n+'</span><span>'+(it.t=='arma'?'Daño '+it.d+'/'+Math.round(it.d/2)+' · Alc. '+it.r+(am!==undefined?' · Mun. '+am+'/'+it.am:''):'Defensa '+it.def)+' · Peso '+it.w+'</span></div>'}
function openAn(){if(!canAct()||!seen())return;mode=null;const e=E,w=wp(e);
const parts=Object.keys(MX).map(k=>{const[c,t]=sc(e.p[k],MX[k]);return '<div class="row"><i class="dot '+c+'"></i><span>'+k+'</span><span class="v">'+e.p[k]+'/'+MX[k]+'</span><em>'+t+'</em></div>'}).join('');
show('<div class="sit"><b>Análisis: '+e.n+'</b></div><div class="v2">Resistencia total '+e.tot+'/36 · Carga '+wt(e)+'/'+e.cap+' · Distancia '+dist(P,E)+' casillas</div>'+parts+'<div class="sit"><b>Equipo</b></div>'+itemRow('Brazo derecho',w,e.am[e.eq.R])+itemRow('Brazo izquierdo',ITEMS[e.eq.L])+'<div class="v2">Con su arma te alcanza hasta '+w.r+' casillas.</div>',false,'análisis');ui()}
function openEq(){if(!pt||anim)return;const w=wt(P);
let h='<div class="sit"><b>Equipamiento</b></div><div class="v2">Carga '+w+'/'+P.cap+'</div><div class="bar2 '+(w>P.cap*.9?'r':w>P.cap*.7?'y':'g')+'"><i style="width:'+Math.min(100,Math.round(w/P.cap*100))+'%"></i></div>';
h+='<div class="sit" style="margin-top:10px"><b>Equipado</b></div>'+itemRow('Brazo derecho',wp(P),P.am[P.eq.R])+itemRow('Brazo izquierdo',ITEMS[P.eq.L]);
h+='<div class="sit" style="margin-top:10px"><b>Mochila</b></div>'+(P.bag.length?P.bag.map((id,i)=>{const it=ITEMS[id],sl=it.t=='arma'?'R':'L',nw=w-ITEMS[P.eq[sl]].w+it.w;
const bad=nw>P.cap?'Excede la carga ('+nw+'/'+P.cap+')':P.p.Brazos<=0?'Brazos destruidos':(!pt||anim||over)?'Solo en tu turno':P.en<1?'Sin energía':'';
return '<div class="it">'+itemRow(it.t=='arma'?'Arma':'Escudo',it,it.t=='arma'?P.am[id]:undefined)+'<button class="eqb" data-i="'+i+'"'+(bad?' disabled':'')+'>'+(bad||'Equipar (1 de energía)')+'</button></div>'}).join(''):'<div class="hint">Mochila vacía.</div>');
show(h,false,'equipo')}
function equip(i){
if(!canAct()||P.en<1||P.p.Brazos<=0||!Number.isInteger(i)||i<0||i>=P.bag.length)return;
const id=P.bag[i],it=ITEMS[id],sl=it.t=='arma'?'R':'L',old=P.eq[sl];
if(wt(P)-ITEMS[old].w+it.w>P.cap)return;
P.eq[sl]=id;P.bag[i]=old;P.en--;
say('Equipas '+it.n+' (energía −1). Guardas '+ITEMS[old].n+' en la mochila.');openEq()}
$('mod').addEventListener('click',e=>{
  const button=e.target.closest('button');
  if(!button||button.disabled)return;
  if(button.hasAttribute('data-rx')&&rxCb&&dialogType==='reacción'){
    const callback=rxCb;
    closeDialog();callback(button.dataset.rx);return;
  }
  if(modLock)return;
  if(button.id==='mx'){closeDialog();return}
  if(button.id==='restart-confirm'&&dialogType==='reinicio'){start();return}
  if(dialogType==='ataque'){
    if(button.id==='fireb'){go();return}
    if(button.hasAttribute('data-ap')){
      cp.m=button.dataset.ap;renderAtk();
      $('mbody').querySelector('[data-ap="'+cp.m+'"]').focus();
    }else if(button.hasAttribute('data-pp')){
      cp.part=button.dataset.pp||null;renderAtk();
      $('mbody').querySelector('[data-pp="'+(cp.part||'')+'"]').focus();
    }
  }else if(dialogType==='equipo'&&button.hasAttribute('data-i'))equip(Number(button.dataset.i));
});
$('beq').onclick=openEq;
$('bre').onclick=()=>{
  if(!canAct()||!inBase(P)||P.en<2)return;
  const repaired=rearm(P);
  addFx({k:'bm',x:P.x,y:P.y,d:450,s:1,c:'79,209,139',r:0});
  say(repaired?'Brazos restaurados a 3/9 y munición recargada.':'Munición reabastecida en la base (energía −2).');
};
$('bsc').onclick=()=>{if(over||!pt||anim)return;if(P.en<1)return say('Sin energía para escanear.');P.en--;
const d=dist(P,E);let z=null,m='Escaneo: obstáculos marcados en el mapa.';
if(d<=VIS)m+=' El enemigo ya está a la vista.';
else if(d<=SCAN){const j=()=>Math.floor(Math.random()*5)-2;z={x:Math.max(0,Math.min(N-1,E.x+j())),y:Math.max(0,Math.min(N-1,E.y+j()))};m+=' Presencia hostil detectada en la zona marcada.';look(z.x,z.y)}
else m+=' Sin presencia hostil en un radio de '+SCAN+' casillas.';
scn={z};say(m)};
$('ban').onclick=()=>{
  if(!canAct()||!seen())return;
  mode=mode==='an'?null:'an';
  say(mode?'Análisis activo. Toca al enemigo en el mapa.':'Análisis cancelado.');
};
$('he').onclick=openAn;
$('help').onclick=()=>show('<h2>Cómo jugar</h2>'+
  '<p>Tienes 6 puntos de energía por turno. Toca una casilla azul para moverte o toca un rival dentro de alcance para disparar. Una casilla bloqueada no permite el paso.</p>'+
  '<p>Arrastra el tablero para recorrerlo. Pellizca o usa los botones + y − para ajustar el zoom. Con teclado, usa las flechas y pulsa Intro para elegir la casilla.</p>'+
  '<p>Escanear revela obstáculos y contactos cercanos. En tu base puedes recargar y recuperar brazos destruidos. La batalla termina al perder la cabina.</p>'+
  '<p>El juego guarda tus acciones terminadas. Si sales durante el turno enemigo, reanudas desde el final de tus acciones anteriores.</p>');
addEventListener('resize',size);size();start(false);if(!restoreBattle())saveBattle();
