package com.mechastacticos.juego;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class MainActivity extends Activity {
    private static final String HOST = "mechas.local";
    private static final String START_URL = "https://" + HOST + "/index.html";
    private static final Map<String, String> ASSET_MIME = assetMimeTypes();
    private FrameLayout root;
    private WebView game;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(17, 24, 32));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 35) applySystemInsets();

        try {
            game = new WebView(this);
        } catch (RuntimeException unavailableWebView) {
            TextView error = new TextView(this);
            error.setGravity(Gravity.CENTER);
            error.setPadding(24, 24, 24, 24);
            error.setText(R.string.webview_error);
            error.setTextColor(Color.WHITE);
            root.addView(error, new FrameLayout.LayoutParams(-1, -1));
            return;
        }

        if (Build.VERSION.SDK_INT < 30) {
            // Older WebView releases can lose the canvas when GPU compositing is unavailable.
            game.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        game.setBackgroundColor(Color.rgb(17, 24, 32));
        WebSettings settings = game.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        game.setWebViewClient(new LocalGameClient());
        root.addView(game, new FrameLayout.LayoutParams(-1, -1));
        game.loadUrl(START_URL);
    }

    private void applySystemInsets() {
        getWindow().setDecorFitsSystemWindows(false);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            Insets visible = insets.getInsets(
                WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout()
            );
            view.setPadding(visible.left, visible.top, visible.right, visible.bottom);
            return WindowInsets.CONSUMED;
        });
        root.requestApplyInsets();
    }

    private static Map<String, String> assetMimeTypes() {
        Map<String, String> types = new HashMap<>();
        types.put("/index.html", "text/html");
        types.put("/game.css", "text/css");
        types.put("/game.js", "application/javascript");
        types.put("/mapa.jpg", "image/jpeg");
        types.put("/vanguard.png", "image/png");
        types.put("/aegis.png", "image/png");
        return Collections.unmodifiableMap(types);
    }

    private static boolean isLocal(Uri uri) {
        return "https".equals(uri.getScheme()) && HOST.equals(uri.getAuthority());
    }

    private final class LocalGameClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return !START_URL.equals(request.getUrl().toString());
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            String path = uri.getPath();
            String mime = isLocal(uri) && "GET".equals(request.getMethod())
                ? ASSET_MIME.get(path) : null;
            if (mime != null) {
                try {
                    return new WebResourceResponse(
                        mime, mime.startsWith("image/") ? null : "UTF-8",
                        getAssets().open(path.substring(1))
                    );
                } catch (IOException ignored) {
                    // The loader returns a 404 for missing files.
                }
            }
            return new WebResourceResponse(
                "text/plain", "UTF-8", 404, "Not Found", Collections.emptyMap(),
                new ByteArrayInputStream("Recurso no disponible".getBytes(StandardCharsets.UTF_8))
            );
        }
    }

    @Override
    public void onBackPressed() {
        if (game == null) {
            finish();
            return;
        }
        game.evaluateJavascript("typeof window.gameBack === 'function' && window.gameBack()",
            handled -> { if (!isFinishing() && !"true".equals(handled)) finish(); });
    }

    @Override
    protected void onPause() {
        if (game != null) game.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (game != null) game.onResume();
    }

    @Override
    protected void onDestroy() {
        if (game != null) {
            root.removeView(game);
            game.destroy();
            game = null;
        }
        super.onDestroy();
    }
}
