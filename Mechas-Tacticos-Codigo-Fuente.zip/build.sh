#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
sdk_root="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
tools="${ANDROID_BUILD_TOOLS:-$sdk_root/build-tools/35.0.0}"
platform="${ANDROID_PLATFORM_JAR:-$sdk_root/platforms/android-35/android.jar}"
source_dir="$PWD/app/src/main"
out="$PWD/build"

if [[ ! -f "$platform" || ! -x "$tools/aapt2" ]]; then
  printf '%s\n' 'Configura un SDK de Android con Platform 35 y Build Tools 35.0.0.' >&2
  exit 1
fi
mkdir -p "$out"
work="$(mktemp -d "$out/work.XXXXXXXX")"
trap 'rm -rf "$work"' EXIT
mkdir -p "$work/classes" "$work/dex" "$work/generated"

"$tools/aapt2" compile --dir "$source_dir/res" -o "$work/resources.zip"
"$tools/aapt2" link -I "$platform" --manifest "$source_dir/AndroidManifest.xml" \
  --java "$work/generated" -A "$source_dir/assets" -o "$work/resources.apk" "$work/resources.zip"

if [[ -n "${ECJ_JAR:-}" ]]; then
  java -jar "$ECJ_JAR" -8 -nowarn -bootclasspath "$platform:$tools/core-lambda-stubs.jar" -d "$work/classes" \
    "$source_dir/java/com/mechastacticos/juego/MainActivity.java" \
    "$work/generated/com/mechastacticos/juego/R.java"
else
  javac -source 8 -target 8 -Xlint:-options -bootclasspath "$platform:$tools/core-lambda-stubs.jar" -d "$work/classes" \
    "$source_dir/java/com/mechastacticos/juego/MainActivity.java" \
    "$work/generated/com/mechastacticos/juego/R.java"
fi
mapfile -d '' -t classes < <(find "$work/classes" -name '*.class' -print0)
"$tools/d8" --release --min-api 26 --lib "$platform" --output "$work/dex" "${classes[@]}"
cp "$work/resources.apk" "$work/unaligned.apk"
(cd "$work/dex" && zip -q "$work/unaligned.apk" classes.dex)
"$tools/zipalign" -f 4 "$work/unaligned.apk" "$work/aligned.apk"

if [[ -z "${MECHAS_KEYSTORE:-}" ]]; then
  MECHAS_KEYSTORE="$out/development.p12"
  if [[ ! -f "$MECHAS_KEYSTORE" ]]; then
    keytool -genkeypair -keystore "$MECHAS_KEYSTORE" -storetype PKCS12 -storepass android \
      -alias mechas -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Mechas Tacticos Development'
  fi
  export MECHAS_STORE_PASS=android
fi
: "${MECHAS_STORE_PASS:?Configura la contraseña del almacén de claves}"
"$tools/apksigner" sign --ks "$MECHAS_KEYSTORE" --ks-key-alias "${MECHAS_KEY_ALIAS:-mechas}" \
  --ks-pass env:MECHAS_STORE_PASS --out "$out/Mechas-Tacticos.apk" "$work/aligned.apk"
"$tools/apksigner" verify --verbose "$out/Mechas-Tacticos.apk"
"$tools/zipalign" -c 4 "$out/Mechas-Tacticos.apk"
