# Mechas tácticos

Juego por turnos para Android 8.0 o superior. Incluye el tablero, las ilustraciones y la lógica del juego dentro de la aplicación. El guardado es local. Al cerrar durante una animación o una reacción enemiga, se reanuda desde la última acción del jugador que terminó.

## Compilar la APK

En Linux, instala un JDK compatible con Android Build Tools, Android SDK Platform 35, Build Tools 35.0.0 y el comando `zip`. Exporta `ANDROID_SDK_ROOT` y ejecuta `./build.sh` con Bash. El resultado se escribe en `build/Mechas-Tacticos.apk`.

El script genera una clave de desarrollo local si aún no existe. Para firmar con tu propia clave, define `MECHAS_KEYSTORE`, `MECHAS_STORE_PASS` y, si corresponde, `MECHAS_KEY_ALIAS`. Android requiere la misma firma para instalar una actualización sobre una versión existente.

## Editar y abrir el juego web

Los archivos del juego están en `app/src/main/assets`. Desde la raíz del proyecto, ejecuta `python3 -m http.server 8000 --directory app/src/main/assets` y abre `http://localhost:8000` para jugar en el navegador.
